#include <list>
#include <vector>
#include <string>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <android/log.h>
#include <map>
#include <cxxabi.h>
#include <cstdlib>
#include <array>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <iterator>
#include <memory>
#include <random>
#include <stdexcept>
#include <ctime>
#include <libgen.h>
#include <sys/time.h>
#include <stdbool.h>
#include <time.h>
#include <elf.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <link.h>
#include <GLES2/gl2.h>
#include <sys/ioctl.h>
#include <ifaddrs.h>
#include <stdarg.h>
#include <signal.h>
#include <ucontext.h>
#include <atomic>
#include <sys/mman.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/utsname.h>
#include <sys/uio.h>
#include <limits.h>
#include <stdio.h>
#include "unwind.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <cstdarg>
#include <sys/syscall.h>
#include <sys/auxv.h>

// ============================ MACROS FOR HOOKING ============================
#define SONIC(RET, NAME, ARGS) \
  RET(*o##NAME) ARGS; \
  RET h##NAME ARGS
  
// ============================ Define constants ============================
#define pkgName "com.dts.freefiremax"

typedef char PACKAGENAME;
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t

#define __int8 char
#define __int32 int
// ============================ Global variables ============================
uintptr_t libanogsBase = 0;
uintptr_t libanogsAlloc = 0;

uintptr_t libil2cppBase = 0;
uintptr_t libil2cppAlloc = 0;

//------------------------- LIBRARY 
uintptr_t findLibrary2(const char *libraryName) {
    char line[512];
    FILE *f = fopen("/proc/self/maps", "rt");
    if (!f) return 0;
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, libraryName)) {
            if (sscanf(line, "%lx-", &base) == 1) break;
        }
    }
    fclose(f);
    return base;
}
//----------------------- HOOKS 

//-----GETTIMEOFDAY fix crash by @SN_IQQ_bot
SONIC(double, sub_494B64, ()) {
    return 0.0;
}
// ============================ MAIN ============================
void* MAIN_THREAD(void*) 
{
    do {
        usleep(100000);
        libanogsBase = findLibrary2(("libanogs.so"));
    } while (!libanogsBase);
    //---------/*
    HOOK_LIB("libanogs.so", "0x494B64", hsub_494B64, osub_494B64); //gettimeofday 
    
    
    //--------
    do {
        usleep(100000);
        libil2cppBase = findLibrary2(("libil2cpp.so"));
    } while (!libil2cppBase);
    //-----
    
    
    //-----
    return nullptr;
}
//================================== 
__attribute__((constructor))
void init_mod() {
    pthread_t DEV_MEROX;
    pthread_create(&DEV_MEROX, nullptr, MAIN_THREAD, nullptr);
}
