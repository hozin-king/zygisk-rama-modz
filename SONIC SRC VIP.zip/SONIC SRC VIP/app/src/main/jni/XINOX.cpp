#include <android/log.h>
#include <unistd.h>
#include <thread>
#include <limits>
#include <xdl.h>
#include <KittyUtils.h>
#include <KittyMemory.h>
#include <Il2Cpp.h>
#include "XINOX STIRKE/Gui.hpp"
#include <XINOX STIRKE/main.h>
#include "fonts/FontAwesome6_solid.h"
#include "ImGui/Toggle.h"
#include "include/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "include/Macros.h"
bool Convidado = false;
static bool isCapsule = false;
static float currentWidth = 650.0f;
static float currentHeight = 380.0f;


#define libil2cpp ("libil2cpp.so")   // ✅ صح
#define libanogs ("libanogs.so")
#define libGGP ("libGGP.so")

static int currentTab = 0; 
void hack_thread();
bool ImGuiOK = true;

pthread_t ptid;  // لازم تعرفها هنا



JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {

    jvm = vm;


    std::thread(hack_thread).detach();

    return JNI_VERSION_1_6;
}

void DrawThickCornerRGB(ImVec2 p_min, ImVec2 p_max, float thickness) {
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    float time = ImGui::GetTime() * 1.5f;
    float corner_size = 25.0f;
    ImU32 col = ImColor::HSV(fmodf(time, 1.0f), 1.0f, 1.0f);
    draw_list->AddRect(p_min, p_max, col, 0.0f, 0, 1.5f);
    draw_list->AddLine(p_min, ImVec2(p_min.x + corner_size, p_min.y), col, thickness);
    draw_list->AddLine(p_min, ImVec2(p_min.x, p_min.y + corner_size), col, thickness);
    draw_list->AddLine(ImVec2(p_max.x, p_min.y), ImVec2(p_max.x - corner_size, p_min.y), col, thickness);
    draw_list->AddLine(ImVec2(p_max.x, p_min.y), ImVec2(p_max.x, p_min.y + corner_size), col, thickness);
    draw_list->AddLine(ImVec2(p_min.x, p_max.y), ImVec2(p_min.x + corner_size, p_max.y), col, thickness);
    draw_list->AddLine(ImVec2(p_min.x, p_max.y), ImVec2(p_min.x, p_max.y - corner_size), col, thickness);
    draw_list->AddLine(p_max, ImVec2(p_max.x - corner_size, p_max.y), col, thickness);
    draw_list->AddLine(p_max, ImVec2(p_max.x, p_max.y - corner_size), col, thickness);
}





ImVec4 GreenAccent = ImVec4(0.00f, 0.85f, 0.45f, 1.00f); 
ImVec4 YellowAccent = ImVec4(1.00f, 0.80f, 0.00f, 1.00f);
ImVec4 DarkBg     = ImVec4(0.08f, 0.09f, 0.11f, 1.00f);
ImVec4 TabBg      = ImVec4(0.12f, 0.12f, 0.14f, 1.00f);
ImVec4 TextWhite  = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);

void SetNeonBlueTheme() {
    ImGuiStyle* style = &ImGui::GetStyle();
    
   style->WindowRounding = 0.0f;
    style->ChildRounding = 5.0f;
    style->FrameRounding = 3.0f;

    style->Colors[ImGuiCol_WindowBg]         = ImVec4(0.11f, 0.12f, 0.17f, 1.00f);
    style->Colors[ImGuiCol_ChildBg]          = ImVec4(0.14f, 0.15f, 0.20f, 1.00f);
    style->Colors[ImGuiCol_Text]               = ImVec4(0.90f, 0.90f, 0.90f, 1.00f);
    style->Colors[ImGuiCol_Separator]          = ImVec4(0.20f, 0.25f, 0.35f, 1.00f);
    style->Colors[ImGuiCol_SliderGrab]       = ImVec4(1.00f, 0.80f, 0.00f, 1.00f);
    style->Colors[ImGuiCol_CheckMark]        = ImVec4(0.20f, 0.80f, 0.40f, 1.00f);
    style->Colors[ImGuiCol_Button]           = ImVec4(0.18f, 0.20f, 0.27f, 1.00f);
}



void(*Bypass1)(void* _this);
void _Bypass1(void* _this) {
    return;
}
void(*Bypass2)(void* _this);
void _Bypass2(void* _this) {
    return;
}
void (*BYPAS)() = 0;
void _BYPAS(void* unk) {
    return;
}


bool XINOXSlider(const char* label, float* value, float min, float max, const char* format = "%.0f") {

    ImGui::Text("%s: ", label);
    ImGui::SameLine();
    ImGui::TextColored(YellowAccent, format, *value);

    float sliderWidth = ImGui::GetContentRegionAvail().x - 10.0f;  
    ImVec2 pos = ImGui::GetCursorScreenPos();  
    ImDrawList* draw = ImGui::GetWindowDrawList();  
    
    ImGui::InvisibleButton(label, ImVec2(sliderWidth, 22));  
    bool changed = false;  
    if (ImGui::IsItemActive()) {  
        float t = (ImGui::GetIO().MousePos.x - pos.x) / sliderWidth;  
        t = ImClamp(t, 0.f, 1.f);  
        *value = min + (max - min) * t;  
        changed = true;  
    }  
    
    float fraction = (*value - min) / (max - min);  
    float radius = 11.f; 
    float knobX = pos.x + radius + (sliderWidth - radius * 2) * fraction;  
    float centerY = pos.y + 11.f;


    draw->AddRectFilled(ImVec2(pos.x, pos.y + 8), ImVec2(pos.x + sliderWidth, pos.y + 14), ImColor(30, 31, 35, 255), 10.0f);  


    ImU32 blue_col = ImGui::ColorConvertFloat4ToU32(YellowAccent);
    draw->AddRectFilled(ImVec2(pos.x, pos.y + 8), ImVec2(knobX, pos.y + 14), blue_col, 10.0f);
    

    draw->AddCircleFilled(ImVec2(knobX, centerY), 7.0f, ImColor(255, 255, 255, 255), 32);
    
    return changed;
}


void XINOX_TOGGLE(const char* label, bool* v) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    
    float height = 22.0f;
    float width = height * 1.85f;
    float radius = height * 0.50f;

    ImGui::InvisibleButton(label, ImVec2(width, height));
    if (ImGui::IsItemClicked()) *v = !*v;

    ImGuiID id = ImGui::GetID(label);
    float animPos = ImGui::GetStateStorage()->GetFloat(id, *v ? 1.0f : 0.0f);
    animPos = ImLerp(animPos, *v ? 1.0f : 0.0f, ImGui::GetIO().DeltaTime * 14.0f);
    ImGui::GetStateStorage()->SetFloat(id, animPos);

    ImVec4 bg_color_v4 = ImLerp(ImVec4(0.20f, 0.20f, 0.22f, 1.00f), GreenAccent, animPos);
    ImU32 bg_col = ImGui::ColorConvertFloat4ToU32(bg_color_v4);

    draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), bg_col, radius);
    
    draw_list->AddRect(p, ImVec2(p.x + width, p.y + height), ImColor(255, 255, 255, 50), radius, 0, 1.0f);

    float knob_pos = p.x + radius + (animPos * (width - radius * 2.0f));
    draw_list->AddCircleFilled(ImVec2(knob_pos, p.y + radius), radius - 2.5f, ImColor(255, 255, 255, 255), 16);
}


uintptr_t il2cpp_base = 0;
void *getRealAddr(ulong offset) {
    return reinterpret_cast<void*>(il2cpp_base + offset);
};

namespace Settings
{
    static int Tab = 1;
}




bool clearMousePos = true;
bool initImGui = false;

    

    
// ============================================
// 🔥 SONIC RED-BLACK ULTIMATE GUI (مُحسّن) 🔥
// ============================================

// إعدادات الألوان الثابتة
static const ImVec4 RED_THEME = ImVec4(0.95f, 0.15f, 0.15f, 1.00f);     // أحمر ناري
static const ImVec4 DARK_RED = ImVec4(0.55f, 0.05f, 0.05f, 1.00f);      // أحمر غامق
static const ImVec4 BLACK_BG = ImVec4(0.08f, 0.08f, 0.10f, 0.98f);       // أسود خلفية
static const ImVec4 DARKER_BG = ImVec4(0.05f, 0.05f, 0.07f, 1.00f);      // أسود أغمق
static const ImVec4 TEXT_WHITE = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);     // نص أبيض
static const ImVec4 TEXT_GRAY = ImVec4(0.70f, 0.70f, 0.75f, 1.00f);      // نص رمادي

// دالة تطبيق الثيم الأحمر والأسود
void ApplyRedBlackTheme() {
    ImGuiStyle& style = ImGui::GetStyle();
    
    // إعدادات عامة (أكبر)
    style.WindowRounding = 15.0f;
    style.ChildRounding = 12.0f;
    style.FrameRounding = 10.0f;
    style.GrabRounding = 8.0f;
    style.PopupRounding = 10.0f;
    style.ScrollbarRounding = 12.0f;
    
    style.WindowPadding = ImVec2(20, 20);
    style.FramePadding = ImVec2(15, 10);
    style.ItemSpacing = ImVec2(12, 15);
    style.ItemInnerSpacing = ImVec2(10, 8);
    style.IndentSpacing = 25.0f;
    style.ScrollbarSize = 15.0f;
    style.GrabMinSize = 20.0f;
    
    // الألوان
    style.Colors[ImGuiCol_WindowBg] = BLACK_BG;
    style.Colors[ImGuiCol_ChildBg] = DARKER_BG;
    style.Colors[ImGuiCol_PopupBg] = DARKER_BG;
    style.Colors[ImGuiCol_Text] = TEXT_WHITE;
    style.Colors[ImGuiCol_TextDisabled] = TEXT_GRAY;
    
    style.Colors[ImGuiCol_Button] = DARK_RED;
    style.Colors[ImGuiCol_ButtonHovered] = RED_THEME;
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.85f, 0.10f, 0.10f, 1.00f);
    
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.12f, 0.12f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.08f, 0.08f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.35f, 0.10f, 0.10f, 1.00f);
    
    style.Colors[ImGuiCol_CheckMark] = RED_THEME;
    style.Colors[ImGuiCol_SliderGrab] = RED_THEME;
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(1.00f, 0.20f, 0.20f, 1.00f);
    
    style.Colors[ImGuiCol_Header] = DARK_RED;
    style.Colors[ImGuiCol_HeaderHovered] = RED_THEME;
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.80f, 0.10f, 0.10f, 1.00f);
    
    style.Colors[ImGuiCol_Separator] = RED_THEME;
    style.Colors[ImGuiCol_SeparatorHovered] = RED_THEME;
    style.Colors[ImGuiCol_Border] = RED_THEME;
    
    style.Colors[ImGuiCol_TitleBg] = DARK_RED;
    style.Colors[ImGuiCol_TitleBgActive] = RED_THEME;
    style.Colors[ImGuiCol_TitleBgCollapsed] = DARK_RED;
}

// دالة رسم الإطار المتوهج
void DrawGlowBorder(ImVec2 p_min, ImVec2 p_max, ImU32 color, float thickness) {
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRect(p_min, p_max, color, 15.0f, 0, thickness);
}

// دالة الزوايا الحمراء
void DrawRedCorners(ImVec2 p_min, ImVec2 p_max, float size, float thickness) {
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImU32 redColor = IM_COL32(220, 40, 40, 255);
    
    // الزاوية العلوية اليسرى
    draw->AddLine(p_min, ImVec2(p_min.x + size, p_min.y), redColor, thickness);
    draw->AddLine(p_min, ImVec2(p_min.x, p_min.y + size), redColor, thickness);
    
    // الزاوية العلوية اليمنى
    draw->AddLine(ImVec2(p_max.x - size, p_min.y), ImVec2(p_max.x, p_min.y), redColor, thickness);
    draw->AddLine(ImVec2(p_max.x, p_min.y), ImVec2(p_max.x, p_min.y + size), redColor, thickness);
    
    // الزاوية السفلية اليسرى
    draw->AddLine(ImVec2(p_min.x, p_max.y - size), ImVec2(p_min.x, p_max.y), redColor, thickness);
    draw->AddLine(ImVec2(p_min.x + size, p_max.y), ImVec2(p_min.x, p_max.y), redColor, thickness);
    
    // الزاوية السفلية اليمنى
    draw->AddLine(ImVec2(p_max.x - size, p_max.y), p_max, redColor, thickness);
    draw->AddLine(ImVec2(p_max.x, p_max.y - size), p_max, redColor, thickness);
}

// ============================================
// 🔥 القائمة الرئيسية (حجم كبير 700x600)
// ============================================


inline EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
inline EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &g_GlWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_GlHeight);
    if (!g_IsSetup) {
        prevWidth = g_GlWidth;
        prevHeight = g_GlHeight;
        SetupImgui();
        
        g_IsSetup = true;
    }
    static bool isTouching = false;
    static float touchStartTime = 0.0f;
//    SetNeonBlueTheme();
    ImGuiIO& io = ImGui::GetIO(); ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(g_GlWidth, g_GlHeight);
	ImGui::NewFrame();
    int touchCount = ((int (*)())(Class_Input__get_touchCount))();
    if (touchCount > 0) {
        UnityEngine_Touch_Fields touch = ((UnityEngine_Touch_Fields(*)(int))(Class_Input__GetTouch))(0);
        float reverseY = io.DisplaySize.y - touch.m_Position.fields.y;
        io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
        if (!isTouching) {
            touchStartTime = ImGui::GetTime();}
        io.MouseDown[0] = true;
        isTouching = true;}
    else {if (isTouching && (ImGui::GetTime() - touchStartTime < 0.06f)) {
        io.MouseDown[0] = true;} else {
        UpdateSpeedhack();
        io.MouseDown[0] = false;
        isTouching = false;
   }  
}

    DrawESP(g_GlWidth, g_GlHeight);
    
static bool itsmk = true;
static bool clickInProgress = false;
static float clickStartTime = 0;

if (itsmk) {
    // حجم أكبر (700x600)
    ImGui::SetNextWindowSize(ImVec2(700.0f, 600.0f), ImGuiCond_FirstUseEver);
    ApplyRedBlackTheme();
    
    // إعدادات النافذة
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 20.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
    
    if (ImGui::Begin("◉  SONIC  ◉", nullptr, ImGuiWindowFlags_NoResize)) {
        
        ImVec2 winPos = ImGui::GetWindowPos();
        ImVec2 winSize = ImGui::GetWindowSize();
        ImVec2 winMax = ImVec2(winPos.x + winSize.x, winPos.y + winSize.y);
        
        // توهج متحرك
        float time = ImGui::GetTime() * 1.5f;
        float glowIntensity = (sinf(time) + 1.0f) / 2.0f;
        ImU32 glowColor = ImColor(200 + (int)(55 * glowIntensity), 20, 20, 255);
        
        DrawGlowBorder(winPos, winMax, glowColor, 4.0f);
        DrawRedCorners(winPos, winMax, 45.0f, 4.5f);
        
        // ===== الهيدر (العنوان) =====
        ImGui::Dummy(ImVec2(0, 12));
        ImGui::SetCursorPosX((ImGui::GetWindowWidth() - 300) * 0.5f);
        ImGui::TextColored(RED_THEME, " SONIC ULTIMATE MOD MENU ");
        ImGui::SetCursorPosX((ImGui::GetWindowWidth() - 200) * 0.5f);
        ImGui::TextColored(TEXT_GRAY, "FreeFire MAX ");
        ImGui::Separator();
        ImGui::Dummy(ImVec2(0, 10));
        
        // ===== التبويبات (أزرار كبيرة) =====
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.12f, 0.15f, 1.00f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, DARK_RED);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, RED_THEME);
        
        float buttonWidth = (ImGui::GetWindowWidth() - 80) / 3;
        
        ImGui::SetCursorPosX(20);
        if (ImGui::Button(" AIMBOT", ImVec2(buttonWidth, 55))) currentTab = 0;
        ImGui::SameLine();
        if (ImGui::Button(" ESP", ImVec2(buttonWidth, 55))) currentTab = 1;
        ImGui::SameLine();
        if (ImGui::Button(" MISC", ImVec2(buttonWidth, 55))) currentTab = 2;
        
        ImGui::PopStyleColor(3);
        ImGui::Dummy(ImVec2(0, 20));
        
        // ===== المحتوى =====
        ImGui::BeginChild("MainContent", ImVec2(0, 440), true);
        ImGui::Indent(15);
        
        if (currentTab == 0) {
            // تبويب AIMBOT
            ImGui::TextColored(RED_THEME, "◉ AIMBOT CONFIGURATION ◉");
            ImGui::Separator();
            ImGui::Dummy(ImVec2(0, 15));
            
            // Enable Aimbot
            ImGui::SetCursorPosX(25);
            ImGui::Text("Enable Aimbot");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##AIM_ENABLE", &Aimbot);
            ImGui::Dummy(ImVec2(0, 15));
            
            // Aim FOV
            ImGui::SetCursorPosX(25);
            ImGui::Text("Aim FOV");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 350);
            XINOXSlider("##FOV_SLIDER", &Fov_Aim, 0.0f, 360.0f);
            ImGui::Dummy(ImVec2(0, 10));
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "  Current FOV Range: %.0f°", Fov_Aim);
            ImGui::Dummy(ImVec2(0, 15));
            
            // Aim Type
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "Aim Priority:");
            ImGui::SameLine();
            ImGui::TextColored(RED_THEME, "  Distance (Nearest)");
            ImGui::Dummy(ImVec2(0, 10));
            
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "Aim Bone:");
            ImGui::SameLine();
            ImGui::TextColored(RED_THEME, "  Head / Body");
        }
        else if (currentTab == 1) {
            // تبويب ESP
            ImGui::TextColored(RED_THEME, "◉ ESP VISUAL CONFIGURATION ◉");
            ImGui::Separator();
            ImGui::Dummy(ImVec2(0, 15));
            
            // Enable ESP
            ImGui::SetCursorPosX(25);
            ImGui::Text("Enable ESP");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##ESP_ENABLE", &Enable);
            ImGui::Dummy(ImVec2(0, 15));
            
            // Line ESP
            ImGui::SetCursorPosX(25);
            ImGui::Text("Line ESP (Snaplines)");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##ESP_LINE", &Config.ESP.Line);
            ImGui::Dummy(ImVec2(0, 12));
            
            // Name ESP
            ImGui::SetCursorPosX(25);
            ImGui::Text("Name ESP");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##ESP_NAME", &Config.ESP.XINOX);
            ImGui::Dummy(ImVec2(0, 12));
            
            // Health ESP
            ImGui::SetCursorPosX(25);
            ImGui::Text("Health ESP (Bar)");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##ESP_HEALTH", &Config.ESP.Health);
            ImGui::Dummy(ImVec2(0, 20));
            
            // Max Distance
            ImGui::SetCursorPosX(25);
            ImGui::Text("Max Draw Distance");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 350);
            XINOXSlider("##DIST_SLIDER", &Aimdis, 0.0f, 500.0f);
            ImGui::Dummy(ImVec2(0, 10));
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "  ESP Range: %.0f meters", Aimdis);
        }
        else {
            // تبويب MISC
            ImGui::TextColored(RED_THEME, "◉ MISCELLANEOUS SETTINGS ◉");
            ImGui::Separator();
            ImGui::Dummy(ImVec2(0, 15));
            
            // Speed Hack
            ImGui::SetCursorPosX(25);
            ImGui::Text("Speed Hack (Movement)");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##SPEED", &SpeedHack);
            ImGui::Dummy(ImVec2(0, 15));
            
            // PC Swap Animation
            ImGui::SetCursorPosX(25);
            ImGui::Text("PC Swap Animation (Fast Switch)");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##PCSWAP", &PcSwapAnim);
            ImGui::Dummy(ImVec2(0, 15));
            
            // Reset Guest
            ImGui::SetCursorPosX(25);
            ImGui::Text("Reset Guest Account");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
            XINOX_TOGGLE("##RESET", &Convidado);
            ImGui::Dummy(ImVec2(0, 30));
            
            // معلومات إضافية
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(RED_THEME, "◉ STATUS ◉");
            ImGui::Separator();
            ImGui::Dummy(ImVec2(0, 10));
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "Mod Status:");
            ImGui::SameLine();
            ImGui::TextColored(RED_THEME, "  ACTIVE");
            ImGui::SetCursorPosX(25);
            ImGui::TextColored(TEXT_GRAY, "Version:");
            ImGui::SameLine();
            ImGui::TextColored(RED_THEME, "  SONIC RED EDITION v1.0");
        }
        
        ImGui::Unindent(15);
        ImGui::EndChild();
        
        // ===== الفوتر =====
        ImGui::Dummy(ImVec2(0, 8));
        ImGui::Separator();
        ImGui::Dummy(ImVec2(0, 5));
        ImGui::SetCursorPosX((ImGui::GetWindowWidth() - 280) * 0.5f);
        ImGui::TextColored(TEXT_GRAY, "SONIC MOD MENU | RED EDITION ");
    }
    
    ImGui::PopStyleVar(2);
    ImGui::End();
}
    
 
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return old_eglSwapBuffers(dpy, surface);
}


typedef unsigned long DWORD;

int address = 0;


#include "SONIC.h"
inline void StartGUI() {
    void *ptr_eglSwapBuffer = DobbySymbolResolver("/system/lib/libEGL.so", "eglSwapBuffers");
    if (ptr_eglSwapBuffer != nullptr) {
        DobbyHook((void *)ptr_eglSwapBuffer, (void *)hook_eglSwapBuffers, (void **)&old_eglSwapBuffers);
        LOGD("GUI started successfully");
    }
}

void hack_thread() {

    sleep(5);
    
    pid_t pid = getpid();
    LOGD("Hack Thread initiated for PID: %i", pid);


    do {
        il2cpp_base = get_module_base(pid, "libil2cpp.so");
        sleep(1);
    } while (il2cpp_base == 0);

    LOGD("libil2cpp.so found at address: 0x%" PRIxPTR, il2cpp_base);


    Il2CppAttach();
    //ur bypass 

    
    StartGUI();
}
